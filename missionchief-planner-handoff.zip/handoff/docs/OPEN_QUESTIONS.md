# Open questions, ranked by impact

## 1 · The remaining 17 extension prices
All are station extensions the player has not yet read off their build menu.
Highest impact first:

| extension | why it matters |
|---|---|
| Disaster Response Extension | with Flood Control, gates the fire path's 1.85M rung |
| Flood Control Extension | same rung |
| Fire Crane Equipment | appears in 39 missions |
| Technical Rescue Equipment | gates Roller Coaster Derailment, 40,000 credits, the EMS ceiling |
| Mountain Rescue Station | carries the entire EMS avalanche branch |
| Sked Equipment / Litter Equipment | same branch |
| Wildland Commando / Wildland Air Command / Smoke Jumper | late fire path, 8–11 stations in |
| ATF / DEA / Bomb Squad / Police Drone / Rotator Truck / Container Slot / Search and Rescue | low priority, all far out |

## 2 · Three name mappings that may be wrong
The mission list and the in-game build menu use different names. Each of these
is an assumption, and each is flagged in `prices.json`:

- **Federal Police Station** (list) vs **Federal Police Extension** (police
  station menu, 200,000). No standalone Federal Police building exists in the
  player's menu. Affects 55 missions including most top-tier fire missions, so a
  wrong mapping here distorts the whole upper fire path.
- **Traffic Police Extension** (list) vs **Traffic Control Extension** (police
  station menu, 200,000). A fire-station Traffic Control Extension was also
  mentioned once. If they are two different things, this price is on the wrong one.
- **Coastal Helicopter Hangar** and **Coastal Plane Hangar** (list) vs
  **Coastal Air Station** (1,000,000, from the weak wiki table, not in the
  player's menu).

## 3 · Classroom expansion price
`prices.json` carries 400,000 per classroom, max 4, **from a Leitstellenspiel
source**. It is used by the alliance kit's "one classroom per 3 members" ratio
rule. Unverified for MissionChief. Verify in an academy build menu.

## 4 · Are the two exercise missions spawnable?
`Forest fire exercise` (24,000) and `Single Vehicle Road Traffic Collision
(Exercise)` (15,000) both sit low on the fire ladder and would displace real
rungs. If exercises must be scheduled manually rather than spawning on their
own, they should be excluded from the ladder. Currently they are shown with a
warning. Needs a forum answer.

## 5 · Coastal Air Station unlock rate
One per 6 coastal rescue stations (wiki table) or one per 20 (another source).
Low urgency.

## 6 · Small-station upgrade cost
Confirmed that upgrading a small station to a full one costs "the difference"
and takes 24 hours. The exact figures are not confirmed. Once known, the ladder
could model the cheap-now-upgrade-later route explicitly.

## 7 · Does the coverage-area split actually pay?
Separate from the tool. Coverage areas confine mission requirements to the
stations inside one dispatch area while the global concurrent-mission cap stays
the same, so splitting into small pockets theoretically means many easy missions
instead of few hard ones. With dispatch centers at 1 + 1 per 15 buildings this
is mechanically reachable early. Whether it yields more credits per hour has
never been measured, by anyone. It is a real open question, not a settled one.
