# The ladder algorithm

## What it replaced, and why

The first version ranked purchases by **total credits of all missions unlocked,
divided by cost**. That was wrong for this game. It favoured buying a couple of
cheap stations that unlocked 140 low-value missions, because 140 small numbers
add up. The player's actual goal is the opposite: reach the *highest-paying
single mission* the path leads to. Mission count is close to irrelevant, because
the number of missions you can run at once is capped anyway (highest count of one
station type, plus one) — extra low-value missions mostly displace each other.

## What it does now

For the selected path, from the player's current state:

1. Take every mission on that path they cannot spawn yet and that has a credit
   value.
2. Compute the shortfall: extra fire / ambulance / police stations, and extra
   count of each required extension.
3. Price the shortfall from the editable price table.
4. Sort candidates by cost ascending, ties broken by credits descending.
5. Walk the sorted list keeping a running maximum, and keep a mission only if it
   pays more than everything cheaper.

What survives is the **cost/credit efficient frontier**: each rung is the
cheapest possible way to raise your ceiling to that level.

### Two properties worth preserving

**Costs are absolute, not incremental.** Every rung is priced from the player's
*current* state, not from the rung above. Rung 4 already contains everything
rung 2 needed. This is stated in the UI because it is otherwise a natural
misreading, and summing the rungs would badly overstate the cost.

**No greedy chaining.** An earlier attempt walked greedily, applying each pick to
the state and recomputing. It produced almost no rungs — it would jump from
750,000 straight to 9,700,000 because that single leap had the best ratio. The
frontier gives a usable 7–14 rung progression instead.

## Path assignment

Computed from each mission's own requirements (see README). Fire stations appear
on every path — the point of the paths is not that they are disjoint, it is that
they aim at different endgames:

- **Fire** — the largest numbers and the longest road. Refineries, power plants,
  aircraft. Top: Power Plant Fire - CBRNE at 56,500.
- **Police** — by far the cheapest start and unusually strong early payouts.
  Top: Clash and assault of risky fans at 23,000.
- **EMS** — terrain-dependent and specialised. Coastal, mountain, aircraft
  crashes. Top: Roller Coaster Derailment (Major) at 40,000.

The strongest single finding in the data: **4 small police stations, 200,000
credits, no extensions, no POI, unlocks a 10,500-credit mission.** Nothing else
in the dataset comes close on credits per credit spent. This contradicts the
common advice to ignore police early, and it fell out of the data rather than
from any guide.

## Deliberately not modelled

- **Build times and training days.** Not in the dataset. A 100,000-credit
  extension with a 7-day build can be a worse buy than a 250,000 one that is
  live immediately. The UI says so rather than pretending otherwise.
- **Income per hour.** The tool ranks unlock efficiency, not earnings. Mission
  spawn frequency, vehicle tie-up time and the concurrent-mission cap all matter
  and none of them are in the data. Do not let the UI imply otherwise.
- **Vehicle costs and slot capacity.** Unlocking a mission is not the same as
  being able to clear it.
