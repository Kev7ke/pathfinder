# Mistakes already made — do not repeat these

Written down because every one of them was stated confidently before being
caught, and most were caught by the player rather than by verification.

## Using the wrong game as a source
The single biggest failure mode. **MissionChief (missionchief.com) is not
Leitstellenspiel.de.** Different buildings, prices, extensions, mechanics.
Leitstellenspiel wikis and forums are the top search results for almost every
query about this genre, in German especially. Several claims in this project
came from there and had to be pulled. Anything sourced from leitstellenspiel.de,
forum.leitstellenspiel.de or leitstellenspiel.fandom.com is **not evidence about
MissionChief** and must be re-verified against a MissionChief source or the
player's own build menu.

The one surviving Leitstellenspiel number is the 400,000 classroom price, still
flagged in `prices.json`. Replace it.

## Dispatch center count — wrong twice
- Claimed 1 per 25 stations (official help centre article).
- A fan table said 1 per 10.
- Truth, from the build menu: **1 + 1 per 15 buildings**, dispatch centers not
  counted.

This mattered: on the strength of the /25 figure the coverage-area strategy was
dismissed as unreachable until ~75 stations. That conclusion was wrong and was
retracted. Even official help-centre articles can be stale.

## Detention Unit Extension — off by 8×
Priced at 25,000 by conflating it with a prison cell. Actually 200,000.
Different things.

## Federal Police — 500,000 vs 200,000
Taken from the wiki table as a standalone 500,000 building requiring rank Staff
Captain. The player's build menu has no such building, only a 200,000 extension.
Corrected, still an assumption.

## Fire Marshal's Office, Tow Truck
Estimated at 100,000 and 200,000; real values 250,000 and 300,000. Both were
load-bearing in recommendations before correction.

## Claimed capabilities that did not exist
Asked to "use agents working in parallel", the honest answer was that no such
tool was available. Do not narrate work that is not happening. Where the answer
is computable from the dataset, compute it — that beats searching anyway.

## Over-trusting a single search result
An earlier AI transcript the player shared contained a fabricated 2,700-station
cap, a wrong mission-cap formula and a wrong dispatch-center rate, all delivered
with citations. Citations are not verification. Two independent sources, or the
player's own screen, or it stays flagged.

## The lesson that generalises
Every number in this project that turned out to be wrong was wrong because it
came from a plausible-looking secondary source. Every number that turned out to
be right came from the player's build menu or from the mission dataset. Weight
accordingly, and keep provenance attached to the data instead of losing it in
prose.
