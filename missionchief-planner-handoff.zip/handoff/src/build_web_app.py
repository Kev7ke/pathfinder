data = open('data2.json').read()

HTML = r'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MissionChief Path Planner</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Saira+Condensed:wght@500;600;700&family=Saira:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{
  --paper:#dae2e7; --card:#eef2f4; --card2:#e3eaed; --field:#fff;
  --ink:#122430; --soft:#4c6373; --rule:#9db0bc;
  --alarm:#ac3227; --alarm-bg:#f3ddda; --go:#1c6650; --warn:#8a5a09;
  --fire:#ac3227; --pol:#1d4f86; --ems:#1c6650;
  --shadow:rgba(18,36,48,.12);
}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){
  --paper:#0d171e; --card:#17232b; --card2:#1d2b35; --field:#0b141a;
  --ink:#dce6eb; --soft:#8da5b2; --rule:#2c4150;
  --alarm:#e6766a; --alarm-bg:#351f1c; --go:#61c199; --warn:#d9a441;
  --fire:#e6766a; --pol:#6ea8e6; --ems:#61c199;
  --shadow:rgba(0,0,0,.4);
}}
:root[data-theme="dark"]{
  --paper:#0d171e; --card:#17232b; --card2:#1d2b35; --field:#0b141a;
  --ink:#dce6eb; --soft:#8da5b2; --rule:#2c4150;
  --alarm:#e6766a; --alarm-bg:#351f1c; --go:#61c199; --warn:#d9a441;
  --fire:#e6766a; --pol:#6ea8e6; --ems:#61c199;
  --shadow:rgba(0,0,0,.4);
}
*{box-sizing:border-box}
body{margin:0;background:var(--paper);color:var(--ink);
  font-family:"Saira","Helvetica Neue",Arial,sans-serif;font-size:16px;line-height:1.5;
  padding:clamp(14px,3vw,38px)}
.wrap{max-width:980px;margin:0 auto}
h1{font-family:"Saira Condensed","Arial Narrow",sans-serif;font-weight:700;
  font-size:clamp(27px,5.5vw,42px);line-height:1.05;margin:0 0 6px;letter-spacing:-.01em}
.sub{color:var(--soft);margin:0 0 22px;max-width:66ch}
h2{font-family:"Saira Condensed",sans-serif;font-weight:700;font-size:20px;
  margin:34px 0 8px;padding-bottom:5px;border-bottom:2px solid var(--rule)}
.lead{color:var(--soft);font-size:14.5px;margin:0 0 14px;max-width:72ch}
.topbar{display:flex;justify-content:flex-end;gap:6px;margin-bottom:8px}
.topbar button{font:inherit;font-size:14px;padding:3px 12px;cursor:pointer;
  background:var(--card);color:var(--soft);border:1px solid var(--rule)}
.topbar button[aria-pressed="true"]{background:var(--ink);color:var(--paper);border-color:var(--ink)}

/* path chooser */
.paths{display:grid;grid-template-columns:repeat(auto-fit,minmax(215px,1fr));gap:12px;margin-bottom:8px}
.pathbtn{text-align:left;background:var(--card);border:1px solid var(--rule);
  border-top:6px solid var(--rule);padding:14px 16px;cursor:pointer;font:inherit;color:var(--ink)}
.pathbtn h3{margin:0;font-family:"Saira Condensed",sans-serif;font-weight:700;font-size:21px}
.pathbtn p{margin:3px 0 0;font-size:13.5px;color:var(--soft)}
.pathbtn[aria-pressed="true"]{box-shadow:0 2px 0 var(--shadow)}
#pb-F[aria-pressed="true"]{border-top-color:var(--fire);background:var(--card2)}
#pb-P[aria-pressed="true"]{border-top-color:var(--pol);background:var(--card2)}
#pb-E[aria-pressed="true"]{border-top-color:var(--ems);background:var(--card2)}

.counts{display:flex;flex-wrap:wrap;gap:12px}
.count{background:var(--card);border:1px solid var(--rule);padding:9px 13px;flex:1 1 150px;min-width:132px}
.count label{display:block;font-size:13px;color:var(--soft)}
.count input{width:100%;border:0;background:transparent;color:var(--ink);
  font-family:"Saira Condensed",sans-serif;font-weight:700;font-size:29px;padding:0}
.count input:focus{outline:2px solid var(--ink);outline-offset:3px}

details{margin-top:14px;background:var(--card);border:1px solid var(--rule)}
summary{cursor:pointer;padding:10px 14px;font-weight:600;font-size:15px;list-style-position:inside}
summary::marker{color:var(--soft)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:6px 16px;padding:4px 14px 14px}
.grid>div{display:flex;align-items:center;gap:8px;font-size:14px;min-width:0}
.grid input{flex:none;background:var(--field);color:var(--ink);
  border:1px solid var(--rule);padding:2px 5px;font:inherit;font-size:14px;text-align:right}
.grid .qty{width:48px} .grid .prc{width:86px}
.grid span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
.grid span.est{color:var(--warn)}
.rowbtns{display:flex;flex-wrap:wrap;gap:8px;padding:0 14px 14px}
.rowbtns button{font:inherit;font-size:13.5px;padding:4px 12px;cursor:pointer;
  background:var(--card2);color:var(--ink);border:1px solid var(--rule)}
.note{padding:0 14px 12px;font-size:13.5px;color:var(--soft);max-width:80ch}

/* ceiling */
.best{background:var(--card);border:1px solid var(--rule);border-top:6px solid var(--alarm);
  box-shadow:0 2px 0 var(--shadow);padding:16px 20px}
.best .tag{font-size:13px;color:var(--soft)}
.best .row{display:flex;flex-wrap:wrap;align-items:baseline;gap:6px 18px}
.best .name,.best .cr{font-family:"Saira Condensed",sans-serif;font-weight:700;
  font-size:clamp(23px,4.2vw,33px);line-height:1.1}
.best .cr{color:var(--alarm);margin-left:auto}
.best .req{color:var(--soft);font-size:14.5px;margin-top:4px}
.empty{color:var(--soft);margin:0}

/* ladder */
.rung{display:flex;gap:16px;background:var(--card);border:1px solid var(--rule);
  border-left:5px solid var(--rule);padding:13px 16px;margin-bottom:10px;flex-wrap:wrap}
.rung.f{border-left-color:var(--fire)} .rung.p{border-left-color:var(--pol)} .rung.e{border-left-color:var(--ems)}
.rung .money{flex:0 0 140px;min-width:120px}
.rung .cost{font-family:"Saira Condensed",sans-serif;font-weight:700;font-size:22px;line-height:1.15}
.rung .costlbl{font-size:12.5px;color:var(--soft)}
.rung .body{flex:1 1 300px;min-width:240px}
.rung .mname{font-weight:600;font-size:16px}
.rung .gain{font-family:"Saira Condensed",sans-serif;font-weight:700;font-size:19px;color:var(--go)}
.rung .buy{font-size:14px;color:var(--soft);margin-top:3px}
.rung .buy b{color:var(--ink);font-weight:600}
.rung .poi{font-size:13px;color:var(--soft);margin-top:2px}
.rung .flag{font-size:13px;color:var(--warn);margin-top:3px}
.rung .est{font-size:13px;color:var(--warn);margin-top:2px}

.tools{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:10px}
.tools input[type=search]{flex:1 1 220px;background:var(--field);color:var(--ink);
  border:1px solid var(--rule);padding:6px 10px;font:inherit;font-size:14.5px}
.tools label{font-size:14px;color:var(--soft);display:flex;align-items:center;gap:7px}
.scroll{overflow-x:auto;-webkit-overflow-scrolling:touch}
table{border-collapse:collapse;width:100%;min-width:560px;font-size:14.5px}
th{text-align:left;font-family:"Saira Condensed",sans-serif;font-weight:700;font-size:15px;
  padding:6px 12px 6px 0;border-bottom:2px solid var(--rule);white-space:nowrap}
td{padding:7px 12px 7px 0;border-bottom:1px solid var(--rule);vertical-align:top}
tbody tr:nth-child(even){background:var(--card2)}
td.n{text-align:right;white-space:nowrap;padding-right:0;
  font-family:"Saira Condensed",sans-serif;font-weight:700;font-size:16px}
td.req{color:var(--soft);font-size:13.5px}
.more{margin:14px 0 0}
.more button{font:inherit;padding:7px 16px;cursor:pointer;background:var(--card);
  color:var(--ink);border:1px solid var(--rule)}
.count-line{color:var(--soft);font-size:14px;margin:0 0 10px}
footer{margin-top:38px;padding-top:13px;border-top:2px solid var(--rule);
  font-size:13.5px;color:var(--soft);max-width:82ch}
@media (max-width:520px){.best .cr{margin-left:0}}
</style>
</head>
<body>
<div class="wrap">

<div class="topbar">
  <button id="btn-en" aria-pressed="true">English</button>
  <button id="btn-de" aria-pressed="false">Deutsch</button>
</div>

<h1 id="t-title"></h1>
<p class="sub" id="t-sub"></p>

<h2 id="t-pathh"></h2>
<p class="lead" id="t-pathlead"></p>
<div class="paths">
  <button class="pathbtn" id="pb-F" aria-pressed="true"><h3 id="t-pf"></h3><p id="t-pfd"></p></button>
  <button class="pathbtn" id="pb-P" aria-pressed="false"><h3 id="t-pp"></h3><p id="t-ppd"></p></button>
  <button class="pathbtn" id="pb-E" aria-pressed="false"><h3 id="t-pe"></h3><p id="t-ped"></p></button>
</div>

<h2 id="t-youh"></h2>
<div class="counts">
  <div class="count"><label for="f" id="t-fire"></label><input id="f" type="number" min="0" max="300" value="6"></div>
  <div class="count"><label for="e" id="t-ems"></label><input id="e" type="number" min="0" max="300" value="0"></div>
  <div class="count"><label for="p" id="t-pol"></label><input id="p" type="number" min="0" max="300" value="0"></div>
</div>

<details id="extbox">
  <summary id="t-extsum"></summary>
  <div class="note" id="t-extnote"></div>
  <div class="note" id="t-sizenote"></div>
  <div class="rowbtns"><button id="sizefull"></button><button id="sizesmall"></button></div>
  <div class="grid" id="stationprices"></div>
  <div class="grid" id="grid"></div>
  <div class="rowbtns"><button id="clr"></button><button id="rstprice"></button></div>
</details>

<h2 id="t-ceilh"></h2>
<div class="best" id="best"></div>

<h2 id="t-ladderh"></h2>
<p class="lead" id="t-ladderlead"></p>
<div id="ladder"></div>

<h2 id="t-allh"></h2>
<div class="tools">
  <input type="search" id="q">
  <label><input type="checkbox" id="pathonly"> <span id="t-pathonly"></span></label>
  <label><input type="checkbox" id="hidezero"> <span id="t-hidezero"></span></label>
</div>
<p class="count-line" id="countline"></p>
<div class="scroll">
  <table><thead><tr>
    <th id="t-cmission"></th><th id="t-creq"></th><th id="t-ccr" style="text-align:right"></th>
  </tr></thead><tbody id="rows"></tbody></table>
</div>
<p class="more"><button id="more"></button></p>

<footer id="t-foot"></footer>

</div>

<script>
const DATA = __DATA__;
const EXT = DATA.ext, M = DATA.m, PATHS = DATA.p;   // m: [name,credits,fire,ems,police,extras,poi,type]

const VERIFIED = {
  "Police Helicopter Station":1000000, "Water Police Extension":200000,
  "Detention Unit Extension":200000, "Game Warden Expansion":20000,
  "Forestry Expansion":50000, "Fire Marshal's Office":250000,
  "Federal Police Station":200000, "Rescue Boat Dock":500000,
  "Fire Boat Dock":500000, "Coastal Rescue Station":500000,
  "Lifeguard Post or Coastal Rescue Station":50000,
  "Coastal Helicopter Hangar":1000000, "Coastal Plane Hangar":1000000,
  "Firefighting Plane Station":1500000, "Foam Extension":100000,
  "Water Rescue Extension":100000, "Airport Extension":100000,
  "Riot Police Extension":250000, "Tow Truck Station":300000,
  "Traffic Police Extension":200000
};
function defPrice(n){
  if(VERIFIED[n]!==undefined) return VERIFIED[n];
  if(/Station|Hangar|Dock|Post/.test(n)) return 200000;
  if(/Equipment|Slot|Sked|Litter/.test(n)) return 50000;
  return 100000;
}
const STATION_FULL={f:100000,e:200000,p:100000}, STATION_SMALL={f:50000,e:100000,p:50000};

const T={
 en:{
  title:"Pick a path. Build toward the money.",
  sub:"Every department has its own big earners and its own route to them. Choose the one you actually want to play, and the ladder below shows the cheapest way to each higher-paying mission on that route — all 1,261 missions from the official US list.",
  pathh:"1 · Your path", pathlead:"Fire stations matter on every path — the difference is what you build them toward. You can switch any time; nothing you own is wasted.",
  pf:"Fire", pfd:"The biggest numbers in the game, and the longest road. Refineries, power plants, aircraft.",
  pp:"Police", ppd:"Cheapest start by far and strong early payouts. Protests, escorts, bomb threats.",
  pe:"EMS / Rescue", ped:"Terrain-dependent and specialised. Coastal, mountain, aircraft crashes, derailments.",
  youh:"2 · What you own",
  fire:"Fire stations", ems:"Ambulance stations", pol:"Police stations",
  extsum:"Extensions, special stations and prices (click to open)",
  extnote:"Left number = how many you own. Right number = what one costs you right now. Orange prices are still my estimates — open the build menu and correct them; the black ones are confirmed.",
  sizenote:"Confirmed: small stations count exactly the same toward mission requirements and cost half, so the ladder defaults to small-station pricing. The catch is capacity — six vehicles and one extension each. Upgrading one to a full station later costs the difference and takes 24 hours. Station prices also rise after your 24th of a type.",
  sizefull:"Price with full stations", sizesmall:"Price with small stations",
  clr:"Set all owned to 0", rstprice:"Reset prices to defaults",
  ceilh:"3 · Your ceiling on this path",
  tag:"Best-paying mission you can currently spawn on this path",
  none:"Nothing on this path spawns for you yet. The first rung below is your way in.",
  ladderh:"4 · The ladder",
  ladderlead:"Each rung is the cheapest purchase that raises your ceiling, measured from where you are right now — not from the rung above. Costs do not stack: reaching rung 4 already includes everything rung 2 needed.",
  cost:"to unlock", from:"from", newtop:"new ceiling",
  buy:"Buy", poi:"Needs a POI", estflag:"Includes an estimated price — check it in the build menu.",
  exflag:"This is an exercise. Confirm it actually spawns on its own before building for it.",
  noladder:"Nothing higher left on this path with these numbers.",
  allh:"5 · Every mission you can get",
  search:"Search mission name…", pathonly:"Only this path", hidezero:"Hide missions without a credit value",
  cmission:"Mission", creq:"Requirements", ccr:"Credits",
  avail:n=>`${n.toLocaleString("en")} missions available.`,
  more:"Show more",
  foot:"Mission data: the Possible Missions list at missionchief.com/einsaetze, exported 16 Sep 2026, all 1,261 rows. Path assignment is computed from each mission's own requirements — whichever department it leans on hardest — not from anyone's opinion. Confirmed prices: fire station 100,000 (small 50,000), ambulance 200,000 (small 100,000), police 100,000 (small 50,000), forestry expansion 50,000, fire marshal's office 250,000, federal police 200,000, rescue and fire boat docks 500,000, coastal rescue station 500,000, lifeguard post 50,000, coastal air station 1,000,000, firefighting plane station 1,500,000, police aviation 1,000,000, water police expansion 200,000, foam / water rescue / airport extension 100,000 each, game warden office 20,000, riot police 250,000, detention unit 200,000, traffic police 200,000, tow truck station 300,000. The remaining 17 are editable estimates. Build times and training days are not modelled — the build menu and the academy show them, and a cheap extension with a 7-day build can still be the wrong pick. Requirement thresholds count per coverage area if you use one, otherwise across your whole account."
 },
 de:{
  title:"Wähl einen Pfad. Bau aufs Geld hin.",
  sub:"Jedes Department hat eigene Großverdiener und einen eigenen Weg dorthin. Wähl den, den du wirklich spielen willst, und die Leiter unten zeigt dir den günstigsten Weg zu jedem besser bezahlten Einsatz auf dieser Route — aus allen 1.261 Einsätzen der offiziellen US-Liste.",
  pathh:"1 · Dein Pfad", pathlead:"Feuerwachen zählen auf jedem Pfad — der Unterschied ist, worauf du sie hin baust. Du kannst jederzeit wechseln, nichts von dem, was du besitzt, ist verloren.",
  pf:"Feuerwehr", pfd:"Die größten Zahlen im Spiel und der längste Weg. Raffinerien, Kraftwerke, Flugzeuge.",
  pp:"Polizei", ppd:"Mit Abstand der billigste Start und starke frühe Auszahlungen. Demos, Eskorten, Bombendrohungen.",
  pe:"Rettungsdienst", ped:"Geländeabhängig und spezialisiert. Küste, Berge, Flugzeugabstürze, Entgleisungen.",
  youh:"2 · Was du hast",
  fire:"Feuerwachen", ems:"Rettungswachen", pol:"Polizeiwachen",
  extsum:"Erweiterungen, Spezialwachen und Preise (zum Öffnen klicken)",
  extnote:"Linke Zahl = wie viele du hast. Rechte Zahl = was eins bei dir gerade kostet. Orange Preise sind noch Schätzungen — schau ins Baumenü und korrigier sie; die schwarzen sind bestätigt.",
  sizenote:"Bestätigt: Kleinwachen zählen für Einsatzanforderungen genau wie normale und kosten die Hälfte, deshalb rechnet die Leiter standardmäßig mit Kleinwachenpreisen. Der Haken ist die Kapazität — sechs Fahrzeuge und eine Erweiterung pro Wache. Der spätere Ausbau zur vollen Wache kostet die Differenz und dauert 24 Stunden. Wachenpreise steigen außerdem ab der 24. Wache eines Typs.",
  sizefull:"Preise für normale Wachen", sizesmall:"Preise für Kleinwachen",
  clr:"Alle Bestände auf 0", rstprice:"Preise zurücksetzen",
  ceilh:"3 · Deine Obergrenze auf diesem Pfad",
  tag:"Bestbezahlter Einsatz, den du auf diesem Pfad aktuell spawnen kannst",
  none:"Auf diesem Pfad spawnt bei dir noch nichts. Die erste Stufe unten ist dein Einstieg.",
  ladderh:"4 · Die Leiter",
  ladderlead:"Jede Stufe ist der günstigste Kauf, der deine Obergrenze anhebt — gerechnet von deinem jetzigen Stand, nicht von der Stufe darüber. Die Kosten addieren sich nicht: Stufe 4 enthält schon alles, was Stufe 2 gebraucht hätte.",
  cost:"zum Freischalten", from:"von", newtop:"neue Obergrenze",
  buy:"Kaufen", poi:"Braucht einen POI", estflag:"Enthält einen geschätzten Preis — im Baumenü prüfen.",
  exflag:"Das ist eine Übung. Prüf, ob sie überhaupt von selbst spawnt, bevor du darauf hin baust.",
  noladder:"Auf diesem Pfad kommt mit diesen Zahlen nichts Höheres mehr.",
  allh:"5 · Alle Einsätze, die du bekommst",
  search:"Einsatzname suchen…", pathonly:"Nur dieser Pfad", hidezero:"Einsätze ohne Credit-Wert ausblenden",
  cmission:"Einsatz", creq:"Voraussetzungen", ccr:"Credits",
  avail:n=>`${n.toLocaleString("de-DE")} Einsätze verfügbar.`,
  more:"Mehr anzeigen",
  foot:"Einsatzdaten: die Possible-Missions-Liste auf missionchief.com/einsaetze, Stand 16.09.2026, alle 1.261 Zeilen. Die Pfadzuordnung ist aus den Anforderungen jedes Einsatzes berechnet — welches Department am stärksten gefordert wird — nicht aus irgendeiner Meinung. Bestätigte Preise: Feuerwache 100.000 (klein 50.000), Rettungswache 200.000 (klein 100.000), Polizeiwache 100.000 (klein 50.000), Forestry Expansion 50.000, Fire Marshal\u2019s Office 250.000, Federal Police 200.000, Rescue und Fire Boat Dock je 500.000, Coastal Rescue Station 500.000, Lifeguard Post 50.000, Coastal Air Station 1.000.000, Firefighting Plane Station 1.500.000, Polizeihubschrauberstation 1.000.000, Water Police Expansion 200.000, Foam / Water Rescue / Airport Extension je 100.000, Game Warden Office 20.000, Riot Police 250.000, Detention Unit 200.000, Traffic Police 200.000, Tow Truck Station 300.000. Die restlichen 17 sind editierbare Sch\u00e4tzungen. Bauzeiten und Lehrgangsdauern sind nicht modelliert — die stehen im Baumenü und in der Akademie, und eine billige Erweiterung mit 7 Tagen Bauzeit kann trotzdem der falsche Kauf sein. Die Schwellen zählen pro Einsatzbereich, falls du einen nutzt, sonst über deinen ganzen Account."
 }
};

let lang="en", path="F", limit=100;
const have={}, price={}, sPrice={...STATION_FULL};
const $=id=>document.getElementById(id);
const t=()=>T[lang];
EXT.forEach(k=>{have[k]=0; price[k]=defPrice(k);});

function save(){
  try{ localStorage.setItem("mc-path", JSON.stringify(
    {f:$("f").value,e:$("e").value,p:$("p").value,have,price,sPrice,lang,path})); }catch(_){}
}
function load(){
  try{
    const s=JSON.parse(localStorage.getItem("mc-path")||"null"); if(!s) return;
    if(s.f!==undefined)$("f").value=s.f; if(s.e!==undefined)$("e").value=s.e; if(s.p!==undefined)$("p").value=s.p;
    if(s.lang==="de"||s.lang==="en") lang=s.lang;
    if("FPE".includes(s.path)) path=s.path;
    EXT.forEach(k=>{
      if(s.have&&s.have[k]!==undefined) have[k]=+s.have[k]||0;
      if(s.price&&s.price[k]!==undefined) price[k]=+s.price[k]||0;
    });
    if(s.sPrice) Object.assign(sPrice,s.sPrice);
  }catch(_){}
}

function fmt(n){ return n===null||n===undefined?"–":Math.round(n).toLocaleString(lang==="de"?"de-DE":"en"); }
function reqText(m){
  const L = lang==="de"
    ? {f:["Feuerwache","Feuerwachen"],e:["Rettungswache","Rettungswachen"],p:["Polizeiwache","Polizeiwachen"]}
    : {f:["fire station","fire stations"],e:["ambulance station","ambulance stations"],p:["police station","police stations"]};
  const o=[];
  if(m[2]) o.push(m[2]+" "+L.f[m[2]===1?0:1]);
  if(m[3]) o.push(m[3]+" "+L.e[m[3]===1?0:1]);
  if(m[4]) o.push(m[4]+" "+L.p[m[4]===1?0:1]);
  for(const k in m[5]) o.push((m[5][k]>1?m[5][k]+"× ":"")+k);
  if(m[6]) o.push("POI: "+m[6]);
  return o.join(" · ");
}
function ok(m,f,e,p){
  if(m[2]>f||m[3]>e||m[4]>p) return false;
  for(const k in m[5]) if((have[k]||0)<m[5][k]) return false;
  return true;
}
function buyList(need){
  const x=t(), o=[];
  if(need.f) o.push(need.f+"× "+x.fire);
  if(need.e) o.push(need.e+"× "+x.ems);
  if(need.p) o.push(need.p+"× "+x.pol);
  for(const k in need.x) o.push(need.x[k]+"× "+k);
  return o;
}

/* ---- the ladder: cost-to-reach frontier for the chosen path ----
   For every mission on this path you cannot spawn yet, work out the
   shortfall and what it costs from your CURRENT state. Sort by cost,
   then keep only the ones that beat everything cheaper. What is left
   is the efficient route: each rung the cheapest way to raise your
   ceiling to that level.                                             */
function frontier(f,e,p){
  let ceiling=null;
  const cand=[];
  for(let i=0;i<M.length;i++){
    if(PATHS[i]!==path) continue;
    const m=M[i]; if(m[1]===null) continue;
    if(ok(m,f,e,p)){ if(!ceiling||m[1]>ceiling[1]) ceiling=m; continue; }
    const need={f:Math.max(0,m[2]-f),e:Math.max(0,m[3]-e),p:Math.max(0,m[4]-p),x:{}};
    let cost=need.f*sPrice.f+need.e*sPrice.e+need.p*sPrice.p, est=false;
    for(const k in m[5]){ const dd=m[5][k]-(have[k]||0); if(dd>0){ need.x[k]=dd; cost+=dd*(price[k]||0); if(VERIFIED[k]===undefined) est=true; } }
    if(cost<=0) continue;
    cand.push({m,need,cost,est});
  }
  const base = ceiling?ceiling[1]:0;
  cand.sort((a,b)=> a.cost-b.cost || b.m[1]-a.m[1]);
  const out=[]; let best=base;
  for(const c of cand){ if(c.m[1]>best){ c.from=best; out.push(c); best=c.m[1]; } }
  return {ceiling,out};
}

function render(){
  const f=+$("f").value||0, e=+$("e").value||0, p=+$("p").value||0, x=t();
  const cls={F:"f",P:"p",E:"e"}[path];
  const {ceiling,out}=frontier(f,e,p);

  $("best").innerHTML = ceiling
    ? `<div class="tag">${x.tag}</div>
       <div class="row"><span class="name">${ceiling[0]}</span><span class="cr">${fmt(ceiling[1])}</span></div>
       <div class="req">${reqText(ceiling)}</div>`
    : `<p class="empty">${x.none}</p>`;

  $("ladder").innerHTML = out.length ? out.map(c=>`
    <div class="rung ${cls}">
      <div class="money">
        <div class="cost">${fmt(c.cost)}</div>
        <div class="costlbl">${x.cost}</div>
      </div>
      <div class="body">
        <div class="mname">${c.m[0]}</div>
        <div><span class="gain">${fmt(c.m[1])}</span>
          <span class="costlbl">${x.newtop} · ${x.from} ${fmt(c.from)}</span></div>
        <div class="buy"><b>${x.buy}:</b> ${buyList(c.need).join(" · ")}</div>
        ${c.m[6]?`<div class="poi">${x.poi}: ${c.m[6]}</div>`:""}
        ${/xercise/i.test(c.m[0])?`<div class="flag">${x.exflag}</div>`:""}
        ${c.est?`<div class="est">${x.estflag}</div>`:""}
      </div>
    </div>`).join("") : `<p class="lead">${x.noladder}</p>`;

  const q=$("q").value.trim().toLowerCase(), hz=$("hidezero").checked, po=$("pathonly").checked;
  let rows=[];
  for(let i=0;i<M.length;i++){
    if(po && PATHS[i]!==path) continue;
    const m=M[i]; if(!ok(m,f,e,p)) continue;
    if(hz && m[1]===null) continue;
    if(q && !m[0].toLowerCase().includes(q)) continue;
    rows.push(m);
  }
  rows.sort((a,b)=>(b[1]===null?-1:b[1])-(a[1]===null?-1:a[1]));
  $("countline").textContent=x.avail(rows.length);
  $("rows").innerHTML=rows.slice(0,limit).map(m=>
    `<tr><td>${m[0]}</td><td class="req">${reqText(m)}</td><td class="n">${fmt(m[1])}</td></tr>`).join("");
  $("more").parentNode.style.display = rows.length>limit?"":"none";
  save();
}

function paintStationPrices(){
  const x=t();
  $("stationprices").innerHTML=[["f",x.fire],["e",x.ems],["p",x.pol]].map(([k,l])=>
    `<div><span>${l}</span><input class="prc" type="number" min="0" step="10000" value="${sPrice[k]}" data-s="${k}" aria-label="${l}"></div>`).join("");
}
function paintGrid(){
  $("grid").innerHTML=EXT.map((n,i)=>
    `<div><input class="qty" type="number" min="0" max="99" value="${have[n]}" data-i="${i}" aria-label="${n}">
     <span class="${VERIFIED[n]===undefined?"est":""}" title="${n}">${n}</span>
     <input class="prc" type="number" min="0" step="5000" value="${price[n]}" data-pi="${i}" aria-label="price ${n}"></div>`).join("");
}
function paintPath(){
  for(const k of ["F","P","E"]) $("pb-"+k).setAttribute("aria-pressed", path===k);
}
function applyLang(){
  const x=t(); document.documentElement.lang=lang;
  $("t-title").textContent=x.title; $("t-sub").textContent=x.sub;
  $("t-pathh").textContent=x.pathh; $("t-pathlead").textContent=x.pathlead;
  $("t-pf").textContent=x.pf; $("t-pfd").textContent=x.pfd;
  $("t-pp").textContent=x.pp; $("t-ppd").textContent=x.ppd;
  $("t-pe").textContent=x.pe; $("t-ped").textContent=x.ped;
  $("t-youh").textContent=x.youh;
  $("t-fire").textContent=x.fire; $("t-ems").textContent=x.ems; $("t-pol").textContent=x.pol;
  $("t-extsum").textContent=x.extsum; $("t-extnote").textContent=x.extnote;
  $("t-sizenote").textContent=x.sizenote;
  $("sizefull").textContent=x.sizefull; $("sizesmall").textContent=x.sizesmall;
  $("clr").textContent=x.clr; $("rstprice").textContent=x.rstprice;
  $("t-ceilh").textContent=x.ceilh;
  $("t-ladderh").textContent=x.ladderh; $("t-ladderlead").textContent=x.ladderlead;
  $("t-allh").textContent=x.allh; $("q").placeholder=x.search;
  $("t-pathonly").textContent=x.pathonly; $("t-hidezero").textContent=x.hidezero;
  $("t-cmission").textContent=x.cmission; $("t-creq").textContent=x.creq; $("t-ccr").textContent=x.ccr;
  $("more").textContent=x.more; $("t-foot").textContent=x.foot;
  $("btn-en").setAttribute("aria-pressed",lang==="en"); $("btn-de").setAttribute("aria-pressed",lang==="de");
  document.title = lang==="de"?"MissionChief Pfad-Planer":"MissionChief Path Planner";
  paintStationPrices(); render();
}

["f","e","p"].forEach(id=>$(id).addEventListener("input",()=>{limit=100;render();}));
$("q").addEventListener("input",()=>{limit=100;render();});
["hidezero","pathonly"].forEach(id=>$(id).addEventListener("change",()=>{limit=100;render();}));
$("grid").addEventListener("input",ev=>{
  const i=ev.target.dataset.i, pi=ev.target.dataset.pi;
  if(i!==undefined) have[EXT[i]]=+ev.target.value||0;
  else if(pi!==undefined) price[EXT[pi]]=+ev.target.value||0;
  else return;
  limit=100; render();
});
$("stationprices").addEventListener("input",ev=>{
  const s=ev.target.dataset.s; if(!s) return; sPrice[s]=+ev.target.value||0; render();
});
$("clr").addEventListener("click",()=>{EXT.forEach(k=>have[k]=0);paintGrid();limit=100;render();});
$("rstprice").addEventListener("click",()=>{
  EXT.forEach(k=>price[k]=defPrice(k)); Object.assign(sPrice,STATION_SMALL);
  paintGrid(); paintStationPrices(); render();
});
$("sizefull").addEventListener("click",()=>{Object.assign(sPrice,STATION_FULL);paintStationPrices();render();});
$("sizesmall").addEventListener("click",()=>{Object.assign(sPrice,STATION_SMALL);paintStationPrices();render();});
["F","P","E"].forEach(k=>$("pb-"+k).addEventListener("click",()=>{path=k;limit=100;paintPath();render();}));
$("btn-en").addEventListener("click",()=>{lang="en";applyLang();});
$("btn-de").addEventListener("click",()=>{lang="de";applyLang();});

load(); paintGrid(); paintPath(); applyLang();
</script>
</body>
</html>
'''
HTML = HTML.replace('__DATA__', data)
open('/mnt/user-data/outputs/missionchief-planner.html','w').write(HTML)
print('written', len(HTML))
