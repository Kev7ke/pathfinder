# MissionChief Path Planner — project handoff

A browser tool for **missionchief.com** (the US version — *not* Leitstellenspiel.de,
which has different buildings, prices and mechanics). It answers one question:

> Given the stations and extensions I own, what is the cheapest thing I can buy
> to unlock a better-paying mission, on the department I actually want to play?

There is a second, smaller deliverable in `web/alliance-kit.html`: an editable
page of copy-ready texts for running an alliance (description, welcome message,
rules, a chat bulletin generator, an internal leadership plan).

---

## What is in here

```
data/
  missions.json       the dataset the app runs on — 1,261 missions
  missions_raw.json   intermediate parse output, one row per mission variant
  prices.json         every known price WITH ITS PROVENANCE. read this first.
docs/
  ALGORITHM.md        how the ladder is computed and why
  OPEN_QUESTIONS.md   what is still unverified, ranked by impact
  CORRECTIONS.md      mistakes already made and fixed — do not repeat them
src/
  parse_pdf.py        extracts missions from a print-to-PDF of the mission list
  build_dataset.py    normalises requirements into structured fields
  build_web_app.py    generates web/planner.html with the data inlined
web/
  planner.html        the current single-file app
  alliance-kit.html   the alliance text kit
CLAUDE_CODE_PROMPT.md the brief for rebuilding this properly
```

---

## The data

`data/missions.json`:

```jsonc
{
  "ext": ["ATF Expansion", "Airport Extension", ...],   // 37 extension names
  "m":   [ [name, credits, fire, ems, police, extras, poi, type], ... ],
  "p":   "FPEFF..."   // one char per mission: F=fire, P=police, E=EMS path
}
```

- `credits` is the **average** credits from the official list, and is `null` for
  ambulance missions, which pay through patient transport instead.
- `extras` is `{ "Foam Extension": 2, ... }` — required count of each extension.
- `poi` is a free-text point-of-interest requirement (Stadium, Forest, Gas
  station…). POIs are free for the player to place, so they are shown but not
  priced.
- `p` is computed, not editorial: police if `police >= fire && police >= ems`,
  else EMS if `ems >= fire && ems >= police`, else fire. Station-less missions
  fall back to the department lean of their extensions. Distribution: 795 fire,
  291 police, 175 EMS.

### Where it came from and how to refresh it

The source is the **Possible Missions** list at `missionchief.com/einsaetze`
(UK: `missionchief.co.uk/einsaetze`). Fetching that page programmatically
truncates around row 114, so the full list was obtained by the player printing
the page to PDF and uploading it. `src/parse_pdf.py` reconstructs the table from
word coordinates with pdfplumber — the text layer alone is not reliable because
mission names, POIs and requirement lists all wrap across lines independently.

To refresh: print the page to PDF again, run `parse_pdf.py` then
`build_dataset.py`. Verify the parse by comparing the count of
`(/einsaetze/` link anchors in the PDF against the number of parsed records —
they must match exactly. They currently do, at 1,261.

---

## The one thing to get right

**Prices are the weak link, not the mission data.** `data/prices.json` marks
every price with a `source`:

| source | meaning | trust |
|---|---|---|
| `build_menu` | the player read it off the live in-game build menu | truth |
| `name_mapped` | a build_menu price, but the in-game name differs from the mission-list name and the mapping is an assumption | check |
| `wiki_table` | from a pasted building list already proven to contain outdated entries | weak |
| `leitstellenspiel` | from the German game — **wrong game**, must be re-verified | do not trust |
| `estimate` | a heuristic guess, not data | replace |

17 of 37 extension prices are still `estimate`. The app renders estimated
prices in orange and flags any recommendation that depends on one. **Keep that
behaviour.** A silently wrong price produces a confident, wrong build order,
which is worse than admitting the gap.

The player is feeding prices in incrementally. Expect `prices.json` to change
often and design for that: prices belong in data, never inline in logic.
